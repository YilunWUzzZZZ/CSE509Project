#include <string.h>
#include <stdio.h>

int main(int argc, char **argv) {
     printf("hello there!\n");

}