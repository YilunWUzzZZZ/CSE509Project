#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/mman.h>

int find_in(char *my_str, char *string_list[], size_t num_strings)
{
            return 1;
}

int safetoread_path(char *pathname)
{
		return 1;
}
